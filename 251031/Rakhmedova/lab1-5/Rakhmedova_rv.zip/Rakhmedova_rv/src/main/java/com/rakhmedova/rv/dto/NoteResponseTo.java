package com.rakhmedova.rv.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.rakhmedova.rv.entity.NoteStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class NoteResponseTo extends BaseDto {
    @JsonProperty("id")
    private BigInteger id;

    @JsonProperty("title")
    private String title;

    @JsonProperty("content")
    private String content;

    @JsonProperty("storyId")
    private BigInteger storyId;

    @JsonProperty("status")
    private NoteStatus status;

    @JsonProperty("moderationReason")
    private String moderationReason;

    @JsonProperty("createdAt")
    private LocalDateTime createdAt;

    @JsonProperty("updatedAt")
    private LocalDateTime updatedAt;
}