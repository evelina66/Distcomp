package com.rakhmedova.rv.service;

import com.rakhmedova.rv.dto.NoteModerationEvent;
import com.rakhmedova.rv.entity.NoteStatus;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.time.LocalDateTime;

@Service
@Slf4j
@RequiredArgsConstructor
public class ModeratorService {
    private final NoteKafkaProducer kafkaProducer;

    public void moderateNote(BigInteger noteId, NoteStatus decision, String reason) {
        if (decision != NoteStatus.APPROVED && decision != NoteStatus.REJECTED) {
            throw new IllegalArgumentException("Invalid moderation decision: " + decision);
        }

        NoteModerationEvent event = new NoteModerationEvent(
            noteId,
            null, // Content not needed for status update
            decision,
            LocalDateTime.now(),
            reason
        );

        log.info("Moderating note: noteId={}, decision={}, reason={}", 
                noteId, decision, reason);
        kafkaProducer.sendNoteForModeration(event);
    }

    public void blockNote(BigInteger noteId, String reason) {
        NoteModerationEvent event = new NoteModerationEvent(
            noteId,
            null,
            NoteStatus.BLOCKED,
            LocalDateTime.now(),
            reason
        );

        log.info("Blocking note: noteId={}, reason={}", noteId, reason);
        kafkaProducer.sendNoteForModeration(event);
    }
} 