package com.rakhmedova.rv.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NoteRequestTo {
    @NotBlank(message = "Content cannot be empty")
    @Size(min = 1, max = 1000, message = "Content must be between 1 and 1000 characters")
    @JsonProperty("content")
    private String content;

    @NotNull(message = "Story ID cannot be null")
    @JsonProperty("storyId")
    private BigInteger storyId;
}