package com.rakhmedova.rv.controller;

import com.rakhmedova.rv.dto.NoteModerationRequest;
import com.rakhmedova.rv.entity.NoteStatus;
import com.rakhmedova.rv.service.ModeratorService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigInteger;

@RestController
@RequestMapping("/api/v1.0/moderator")
@RequiredArgsConstructor
public class ModeratorController {
    private final ModeratorService moderatorService;

    @PostMapping("/notes/{noteId}/approve")
    public ResponseEntity<Void> approveNote(
            @PathVariable BigInteger noteId,
            @RequestBody(required = false) @Valid NoteModerationRequest request) {
        String reason = request != null ? request.getReason() : null;
        moderatorService.moderateNote(noteId, NoteStatus.APPROVED, reason);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/notes/{noteId}/reject")
    public ResponseEntity<Void> rejectNote(
            @PathVariable BigInteger noteId,
            @RequestBody @Valid NoteModerationRequest request) {
        moderatorService.moderateNote(noteId, NoteStatus.REJECTED, request.getReason());
        return ResponseEntity.ok().build();
    }

    @PostMapping("/notes/{noteId}/block")
    public ResponseEntity<Void> blockNote(
            @PathVariable BigInteger noteId,
            @RequestBody @Valid NoteModerationRequest request) {
        moderatorService.blockNote(noteId, request.getReason());
        return ResponseEntity.ok().build();
    }
} 