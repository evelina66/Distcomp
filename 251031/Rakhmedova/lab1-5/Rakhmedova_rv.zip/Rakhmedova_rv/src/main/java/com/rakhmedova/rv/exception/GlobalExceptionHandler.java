package com.rakhmedova.rv.exception;

import com.rakhmedova.rv.dto.ErrorResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(AppException.class)
    public ResponseEntity<ErrorResponse> handleAppException(AppException ex) {
        ErrorResponse error = new ErrorResponse();
        error.setErrorMessage(ex.getMessage());
        error.setErrorCode(ex.getErrorCode());
        return new ResponseEntity<>(error, HttpStatus.valueOf(Integer.parseInt(ex.getErrorCode().substring(0, 3))));
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidationException(MethodArgumentNotValidException ex) {
        FieldError fieldError = ex.getBindingResult().getFieldError();
        String message = fieldError != null ? fieldError.getDefaultMessage() : "Validation failed";
        ErrorResponse error = new ErrorResponse();
        error.setErrorMessage(message);
        error.setErrorCode("40001");
        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ErrorResponse> handleIllegalArgumentException(IllegalArgumentException ex) {
        ErrorResponse error = new ErrorResponse();
        error.setErrorMessage(ex.getMessage());
        error.setErrorCode("40401");
        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }
}