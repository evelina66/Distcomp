package com.rakhmedova.rv.mapper;

import com.rakhmedova.rv.dto.NoteRequestTo;
import com.rakhmedova.rv.dto.NoteResponseTo;
import com.rakhmedova.rv.entity.Note;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "spring")
public interface NoteMapper {
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "story", ignore = true)
    @Mapping(target = "status", constant = "PENDING")
    @Mapping(target = "createdAt", expression = "java(java.time.LocalDateTime.now())")
    @Mapping(target = "updatedAt", expression = "java(java.time.LocalDateTime.now())")
    @Mapping(target = "moderationReason", ignore = true)
    Note toEntity(NoteRequestTo requestTo);

    @Mapping(target = "storyId", source = "story.id")
    NoteResponseTo toResponseTo(Note note);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "story", ignore = true)
    @Mapping(target = "status", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", expression = "java(java.time.LocalDateTime.now())")
    @Mapping(target = "moderationReason", ignore = true)
    void updateEntity(@MappingTarget Note target, NoteRequestTo source);
}