package com.rakhmedova.rv.repository;

import com.rakhmedova.rv.entity.BaseEntity;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

public interface Repository<T extends BaseEntity> {
    T save(T entity);
    Optional<T> findById(BigInteger id);
    List<T> findAll();
    T update(T entity);
    void delete(BigInteger id);
}