package com.rakhmedova.rv.service;

import com.rakhmedova.rv.dto.MarkRequestTo;
import com.rakhmedova.rv.dto.MarkResponseTo;
import com.rakhmedova.rv.entity.Mark;
import com.rakhmedova.rv.entity.Story;
import com.rakhmedova.rv.mapper.MarkMapper;
import com.rakhmedova.rv.repository.MarkRepository;
import com.rakhmedova.rv.repository.StoryRepository;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import java.math.BigInteger;
import java.util.List;
import java.util.NoSuchElementException;

@Service
@Validated
@RequiredArgsConstructor
public class MarkService {
    private final MarkRepository markRepository;
    private final StoryRepository storyRepository;
    private final MarkMapper markMapper;

    @Transactional
    public MarkResponseTo create(@Valid MarkRequestTo requestTo, BigInteger storyId) {
        Story story = storyRepository.findById(storyId)
                .orElseThrow(() -> new NoSuchElementException("Story not found with id: " + storyId));

        Mark mark = markMapper.toEntity(requestTo);
        mark = markRepository.save(mark);
        story.getMarks().add(mark);
        storyRepository.save(story);

        return markMapper.toResponseTo(mark);
    }

    @Transactional(readOnly = true)
    public MarkResponseTo findById(BigInteger id) {
        Mark mark = markRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Mark not found with id: " + id));
        return markMapper.toResponseTo(mark);
    }

    @Transactional(readOnly = true)
    public List<MarkResponseTo> findAll() {
        return markRepository.findAll().stream()
                .map(markMapper::toResponseTo)
                .toList();
    }

    @Transactional
    public MarkResponseTo update(BigInteger id, @Valid MarkRequestTo requestTo) {
        Mark mark = markRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Mark not found with id: " + id));

        markMapper.updateEntity(mark, requestTo);
        mark = markRepository.save(mark);

        return markMapper.toResponseTo(mark);
    }

    @Transactional
    public void delete(BigInteger id) {
        if (!markRepository.existsById(id)) {
            throw new NoSuchElementException("Mark not found with id: " + id);
        }
        markRepository.deleteById(id);
    }
}