package com.rakhmedova.rv.service;

import com.rakhmedova.rv.dto.CreatorRequestTo;
import com.rakhmedova.rv.dto.CreatorResponseTo;
import com.rakhmedova.rv.entity.Creator;
import com.rakhmedova.rv.mapper.CreatorMapper;
import com.rakhmedova.rv.repository.CreatorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigInteger;
import java.util.List;
import java.util.NoSuchElementException;

@Service
@RequiredArgsConstructor
public class CreatorService {
    private final CreatorRepository creatorRepository;
    private final CreatorMapper creatorMapper;

    @Transactional
    public Creator create(CreatorRequestTo requestTo) {
        Creator creator = creatorMapper.toEntity(requestTo);
        return creatorRepository.save(creator);
    }

    @Transactional(readOnly = true)
    public Creator findById(BigInteger id) {
        return creatorRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Creator not found with id: " + id));
    }

    @Transactional(readOnly = true)
    public List<CreatorResponseTo> findAll() {
        return creatorRepository.findAll().stream()
                .map(creatorMapper::toResponseTo)
                .toList();
    }

    @Transactional
    public Creator update(BigInteger id, CreatorRequestTo requestTo) {
        Creator creator = findById(id);
        creatorMapper.updateEntity(creator, requestTo);
        return creatorRepository.save(creator);
    }

    @Transactional
    public void delete(BigInteger id) {
        if (!creatorRepository.existsById(id)) {
            throw new NoSuchElementException("Creator not found with id: " + id);
        }
        creatorRepository.deleteById(id);
    }
}