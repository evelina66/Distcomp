package com.rakhmedova.rv.service;

import com.rakhmedova.rv.dto.NoteRequestTo;
import com.rakhmedova.rv.dto.NoteResponseTo;
import com.rakhmedova.rv.entity.Note;
import com.rakhmedova.rv.entity.NoteStatus;
import com.rakhmedova.rv.entity.Story;
import com.rakhmedova.rv.mapper.NoteMapper;
import com.rakhmedova.rv.repository.NoteRepository;
import com.rakhmedova.rv.repository.StoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import java.math.BigInteger;
import java.util.List;
import java.util.NoSuchElementException;

@Service
@Validated
@RequiredArgsConstructor
public class NoteService {
    private final NoteRepository noteRepository;
    private final StoryRepository storyRepository;
    private final NoteMapper noteMapper;
    @SuppressWarnings("unused")
    private final NoteKafkaProducer kafkaProducer;

    @Transactional
    public NoteResponseTo create(NoteRequestTo requestTo, BigInteger storyId) {
        Story story = storyRepository.findById(storyId)
                .orElseThrow(() -> new NoSuchElementException("Story not found with id: " + storyId));

        Note note = noteMapper.toEntity(requestTo);
        note.setStory(story);
        note = noteRepository.save(note);

        return noteMapper.toResponseTo(note);
    }

    @Transactional(readOnly = true)
    public NoteResponseTo findById(BigInteger id) {
        Note note = noteRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Note not found with id: " + id));
        return noteMapper.toResponseTo(note);
    }

    @Transactional(readOnly = true)
    public List<NoteResponseTo> findAll() {
        return noteRepository.findAll().stream()
                .map(noteMapper::toResponseTo)
                .toList();
    }

    @Transactional
    public NoteResponseTo update(BigInteger id, NoteRequestTo requestTo) {
        Note note = noteRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Note not found with id: " + id));

        noteMapper.updateEntity(note, requestTo);
        note = noteRepository.save(note);

        return noteMapper.toResponseTo(note);
    }

    @Transactional
    public void delete(BigInteger id) {
        if (!noteRepository.existsById(id)) {
            throw new NoSuchElementException("Note not found with id: " + id);
        }
        noteRepository.deleteById(id);
    }

    @CacheEvict(value = "notes", allEntries = true)
    public void updateNoteStatus(BigInteger id, NoteStatus status, String moderationReason) {
        Note note = noteRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Note with id " + id + " not found"));
        
        note.setStatus(status);
        note.setModerationReason(moderationReason);
        noteRepository.save(note);
    }
}