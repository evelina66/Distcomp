package com.rakhmedova.rv.dto;

import lombok.Data;
import java.math.BigInteger;

@Data
public class CreatorResponseTo {
    private BigInteger id;
    private String firstName;
    private String lastName;
    private String email;
    private String phone;
}