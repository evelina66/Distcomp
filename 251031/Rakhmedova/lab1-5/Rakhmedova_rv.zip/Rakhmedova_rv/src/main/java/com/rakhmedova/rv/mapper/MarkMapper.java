package com.rakhmedova.rv.mapper;

import com.rakhmedova.rv.dto.MarkRequestTo;
import com.rakhmedova.rv.dto.MarkResponseTo;
import com.rakhmedova.rv.entity.Mark;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "spring")
public interface MarkMapper {
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "stories", ignore = true)
    Mark toEntity(MarkRequestTo requestTo);

    MarkResponseTo toResponseTo(Mark mark);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "stories", ignore = true)
    void updateEntity(@MappingTarget Mark target, MarkRequestTo source);
}