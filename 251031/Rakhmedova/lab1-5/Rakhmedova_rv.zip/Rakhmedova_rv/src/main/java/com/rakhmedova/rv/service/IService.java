package com.rakhmedova.rv.service;

import jakarta.validation.Valid;
import java.math.BigInteger;
import java.util.List;

public interface IService<T, R> {
    R create(@Valid T request);
    R findById(BigInteger id);
    List<R> findAll();
    R update(BigInteger id, @Valid T request);
    void delete(BigInteger id);
} 