package com.rakhmedova.rv.service;

import com.rakhmedova.rv.dto.StoryRequestTo;
import com.rakhmedova.rv.dto.StoryResponseTo;
import com.rakhmedova.rv.entity.Creator;
import com.rakhmedova.rv.entity.Mark;
import com.rakhmedova.rv.entity.Story;
import com.rakhmedova.rv.mapper.StoryMapper;
import com.rakhmedova.rv.repository.CreatorRepository;
import com.rakhmedova.rv.repository.MarkRepository;
import com.rakhmedova.rv.repository.StoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class StoryService {
    private final StoryRepository storyRepository;
    private final CreatorRepository creatorRepository;
    private final MarkRepository markRepository;
    private final StoryMapper storyMapper;

    @Transactional
    public StoryResponseTo create(StoryRequestTo requestTo) {
        Story story = storyMapper.toEntity(requestTo);
        
        Creator creator = creatorRepository.findById(requestTo.getCreatorId())
                .orElseThrow(() -> new NoSuchElementException("Creator not found with id: " + requestTo.getCreatorId()));
        story.setCreator(creator);

        if (requestTo.getMarkIds() != null && !requestTo.getMarkIds().isEmpty()) {
            Set<Mark> marks = new HashSet<>(markRepository.findAllById(requestTo.getMarkIds()));
            story.setMarks(marks);
        }

        story.setCreated(LocalDateTime.now());
        story.setModified(LocalDateTime.now());
        
        story = storyRepository.save(story);
        return storyMapper.toResponseTo(story);
    }

    @Transactional(readOnly = true)
    public StoryResponseTo findById(BigInteger id) {
        Story story = storyRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Story not found with id: " + id));
        return storyMapper.toResponseTo(story);
    }

    @Transactional(readOnly = true)
    public List<StoryResponseTo> findAll() {
        return storyRepository.findAll().stream()
                .map(storyMapper::toResponseTo)
                .toList();
    }

    @Transactional
    public StoryResponseTo update(BigInteger id, StoryRequestTo requestTo) {
        Story story = storyRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Story not found with id: " + id));
        storyMapper.updateEntity(story, requestTo);

        Creator creator = creatorRepository.findById(requestTo.getCreatorId())
                .orElseThrow(() -> new NoSuchElementException("Creator not found with id: " + requestTo.getCreatorId()));
        story.setCreator(creator);

        if (requestTo.getMarkIds() != null && !requestTo.getMarkIds().isEmpty()) {
            Set<Mark> marks = new HashSet<>(markRepository.findAllById(requestTo.getMarkIds()));
            story.setMarks(marks);
        }

        story.setModified(LocalDateTime.now());
        
        story = storyRepository.save(story);
        return storyMapper.toResponseTo(story);
    }

    @Transactional
    public void delete(BigInteger id) {
        if (!storyRepository.existsById(id)) {
            throw new NoSuchElementException("Story not found with id: " + id);
        }
        storyRepository.deleteById(id);
    }
}