package com.rakhmedova.rv.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class StoryResponseTo {
    @JsonProperty("id")
    private BigInteger id;

    @JsonProperty("title")
    private String title;

    @JsonProperty("content")
    private String content;

    @JsonProperty("creatorId")
    private BigInteger creatorId;

    @JsonProperty("created")
    private LocalDateTime created;

    @JsonProperty("modified")
    private LocalDateTime modified;

    @JsonProperty("marks")
    private Set<MarkResponseTo> marks;

    @JsonProperty("notes")
    private Set<NoteResponseTo> notes;
}