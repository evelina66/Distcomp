package com.rakhmedova.rv.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class StoryRequestTo {
    @NotBlank(message = "Title cannot be empty")
    @Size(min = 1, max = 255, message = "Title must be between 1 and 255 characters")
    @JsonProperty("title")
    private String title;

    @NotBlank(message = "Content cannot be empty")
    @Size(min = 1, max = 2048, message = "Content must be between 1 and 2048 characters")
    @JsonProperty("content")
    private String content;

    @NotNull(message = "Creator ID is required")
    @JsonProperty("creatorId")
    private BigInteger creatorId;

    @JsonProperty("markIds")
    private Set<BigInteger> markIds;
}