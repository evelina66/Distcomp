package com.rakhmedova.rv.controller;

import com.rakhmedova.rv.dto.MarkRequestTo;
import com.rakhmedova.rv.dto.MarkResponseTo;
import com.rakhmedova.rv.service.MarkService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigInteger;
import java.util.List;

@RestController
@RequestMapping("/api/v1/marks")
@Tag(name = "Marks", description = "Operations with marks")
public class MarkController {
    private final MarkService service;

    public MarkController(MarkService service) {
        this.service = service;
    }

    @PostMapping("/stories/{storyId}")
    @Operation(summary = "Create a new mark for a story")
    @ApiResponse(responseCode = "201", description = "Mark created successfully")
    @ApiResponse(responseCode = "404", description = "Story not found")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    public ResponseEntity<MarkResponseTo> create(
            @Parameter(description = "Story ID", required = true) @PathVariable BigInteger storyId,
            @Parameter(description = "Mark data", required = true) @Valid @RequestBody MarkRequestTo request) {
        MarkResponseTo response = service.create(request, storyId);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get mark by ID")
    @ApiResponse(responseCode = "200", description = "Mark found")
    @ApiResponse(responseCode = "404", description = "Mark not found")
    public ResponseEntity<MarkResponseTo> findById(
            @Parameter(description = "Mark ID", required = true) @PathVariable BigInteger id) {
        MarkResponseTo response = service.findById(id);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping
    @Operation(summary = "Get all marks")
    @ApiResponse(responseCode = "200", description = "List of marks")
    public ResponseEntity<List<MarkResponseTo>> findAll() {
        List<MarkResponseTo> responses = service.findAll();
        return new ResponseEntity<>(responses, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update mark by ID")
    @ApiResponse(responseCode = "200", description = "Mark updated successfully")
    @ApiResponse(responseCode = "404", description = "Mark not found")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    public ResponseEntity<MarkResponseTo> update(
            @Parameter(description = "Mark ID", required = true) @PathVariable BigInteger id,
            @Parameter(description = "Updated mark data", required = true) @Valid @RequestBody MarkRequestTo request) {
        MarkResponseTo response = service.update(id, request);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete mark by ID")
    @ApiResponse(responseCode = "204", description = "Mark deleted successfully")
    @ApiResponse(responseCode = "404", description = "Mark not found")
    public ResponseEntity<Void> delete(
            @Parameter(description = "Mark ID", required = true) @PathVariable BigInteger id) {
        service.delete(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}