package com.rakhmedova.rv.controller;

import com.rakhmedova.rv.dto.StoryRequestTo;
import com.rakhmedova.rv.dto.StoryResponseTo;
import com.rakhmedova.rv.service.StoryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigInteger;
import java.util.List;

@RestController
@RequestMapping("/api/v1/stories")
@Tag(name = "Stories", description = "Operations with stories")
public class StoryController {
    private final StoryService service;

    public StoryController(StoryService service) {
        this.service = service;
    }

    @PostMapping
    @Operation(summary = "Create a new story")
    @ApiResponse(responseCode = "201", description = "Story created successfully")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    public ResponseEntity<StoryResponseTo> create(
            @Parameter(description = "Story data", required = true) @Valid @RequestBody StoryRequestTo request) {
        StoryResponseTo response = service.create(request);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get story by ID")
    @ApiResponse(responseCode = "200", description = "Story found")
    @ApiResponse(responseCode = "404", description = "Story not found")
    public ResponseEntity<StoryResponseTo> findById(
            @Parameter(description = "Story ID", required = true) @PathVariable BigInteger id) {
        StoryResponseTo response = service.findById(id);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping
    @Operation(summary = "Get all stories")
    @ApiResponse(responseCode = "200", description = "List of stories")
    public ResponseEntity<List<StoryResponseTo>> findAll() {
        List<StoryResponseTo> responses = service.findAll();
        return new ResponseEntity<>(responses, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update story by ID")
    @ApiResponse(responseCode = "200", description = "Story updated successfully")
    @ApiResponse(responseCode = "404", description = "Story not found")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    public ResponseEntity<StoryResponseTo> update(
            @Parameter(description = "Story ID", required = true) @PathVariable BigInteger id,
            @Parameter(description = "Updated story data", required = true) @Valid @RequestBody StoryRequestTo request) {
        StoryResponseTo response = service.update(id, request);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete story by ID")
    @ApiResponse(responseCode = "204", description = "Story deleted successfully")
    @ApiResponse(responseCode = "404", description = "Story not found")
    public ResponseEntity<Void> delete(
            @Parameter(description = "Story ID", required = true) @PathVariable BigInteger id) {
        service.delete(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}