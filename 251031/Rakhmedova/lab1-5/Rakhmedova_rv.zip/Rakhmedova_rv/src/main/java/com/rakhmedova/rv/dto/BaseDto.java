package com.rakhmedova.rv.dto;

import lombok.Data;

import java.math.BigInteger;

@Data
public abstract class BaseDto {
    protected BigInteger id;
}