package com.rakhmedova.rv.mapper;

import com.rakhmedova.rv.dto.CreatorRequestTo;
import com.rakhmedova.rv.dto.CreatorResponseTo;
import com.rakhmedova.rv.entity.Creator;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "spring")
public interface CreatorMapper {
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "stories", ignore = true)
    Creator toEntity(CreatorRequestTo requestTo);
    
    CreatorResponseTo toResponseTo(Creator creator);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "stories", ignore = true)
    void updateEntity(@MappingTarget Creator target, CreatorRequestTo source);
}