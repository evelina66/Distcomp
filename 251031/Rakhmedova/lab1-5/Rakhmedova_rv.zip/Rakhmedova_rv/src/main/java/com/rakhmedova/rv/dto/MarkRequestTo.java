package com.rakhmedova.rv.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class MarkRequestTo {
    @NotBlank
    private String name;
}