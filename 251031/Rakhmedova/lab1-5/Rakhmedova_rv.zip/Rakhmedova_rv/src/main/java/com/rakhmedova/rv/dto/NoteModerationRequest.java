package com.rakhmedova.rv.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NoteModerationRequest {
    @NotNull(message = "Moderation reason is required for rejection and blocking")
    @Size(min = 10, max = 500, message = "Reason must be between 10 and 500 characters")
    private String reason;
} 