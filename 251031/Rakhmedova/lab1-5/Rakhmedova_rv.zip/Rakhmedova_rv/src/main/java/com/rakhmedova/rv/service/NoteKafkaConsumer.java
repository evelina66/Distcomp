package com.rakhmedova.rv.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rakhmedova.rv.config.KafkaConfig;
import com.rakhmedova.rv.dto.NoteModerationEvent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class NoteKafkaConsumer {
    private final ObjectMapper objectMapper;
    private final NoteService noteService;

    @KafkaListener(topics = KafkaConfig.NOTE_STATUS_UPDATE_TOPIC)
    public void handleNoteStatusUpdate(@Payload String message) {
        try {
            NoteModerationEvent event = objectMapper.readValue(message, NoteModerationEvent.class);
            log.info("Received note status update: noteId={}, status={}", 
                    event.getNoteId(), event.getStatus());
            
            noteService.updateNoteStatus(event.getNoteId(), 
                                       event.getStatus(), 
                                       event.getModerationReason());
        } catch (Exception e) {
            log.error("Error processing note status update", e);
        }
    }
} 