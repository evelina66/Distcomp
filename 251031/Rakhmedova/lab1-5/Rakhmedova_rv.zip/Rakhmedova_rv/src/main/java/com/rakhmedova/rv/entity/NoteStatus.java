package com.rakhmedova.rv.entity;

public enum NoteStatus {
    PENDING,    // Initial state when note is created
    APPROVED,   // Note has been approved by moderator
    REJECTED,   // Note has been rejected by moderator
    BLOCKED     // Note has been blocked due to violation
} 