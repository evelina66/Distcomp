package com.rakhmedova.rv.controller;

import com.rakhmedova.rv.dto.CreatorRequestTo;
import com.rakhmedova.rv.dto.CreatorResponseTo;
import com.rakhmedova.rv.mapper.CreatorMapper;
import com.rakhmedova.rv.service.CreatorService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigInteger;
import java.util.List;

@RestController
@RequestMapping("/api/creators")
@RequiredArgsConstructor
public class CreatorController {
    private final CreatorService creatorService;
    private final CreatorMapper creatorMapper;

    @PostMapping
    public ResponseEntity<CreatorResponseTo> create(@Valid @RequestBody CreatorRequestTo requestTo) {
        var creator = creatorService.create(requestTo);
        var responseTo = creatorMapper.toResponseTo(creator);
        return new ResponseEntity<>(responseTo, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<CreatorResponseTo> findById(@PathVariable BigInteger id) {
        var creator = creatorService.findById(id);
        var responseTo = creatorMapper.toResponseTo(creator);
        return ResponseEntity.ok(responseTo);
    }

    @GetMapping
    public ResponseEntity<List<CreatorResponseTo>> findAll() {
        return ResponseEntity.ok(creatorService.findAll());
    }

    @PutMapping("/{id}")
    public ResponseEntity<CreatorResponseTo> update(
            @PathVariable BigInteger id,
            @Valid @RequestBody CreatorRequestTo requestTo) {
        var creator = creatorService.update(id, requestTo);
        var responseTo = creatorMapper.toResponseTo(creator);
        return ResponseEntity.ok(responseTo);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable BigInteger id) {
        creatorService.delete(id);
        return ResponseEntity.noContent().build();
    }
}