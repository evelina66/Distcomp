package com.rakhmedova.rv.mapper;

import org.mapstruct.Mapper;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;

@Mapper(componentModel = "spring")
public interface DateTimeMapper {
    default LocalDateTime map(OffsetDateTime value) {
        return value != null ? value.toLocalDateTime() : null;
    }

    default OffsetDateTime map(LocalDateTime value) {
        return value != null ? OffsetDateTime.from(value.atOffset(java.time.ZoneOffset.UTC)) : null;
    }
} 