package com.rakhmedova.rv.mapper;

import com.rakhmedova.rv.dto.StoryRequestTo;
import com.rakhmedova.rv.dto.StoryResponseTo;
import com.rakhmedova.rv.entity.Story;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "spring", uses = {MarkMapper.class, NoteMapper.class})
public interface StoryMapper {
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "creator", ignore = true)
    @Mapping(target = "marks", ignore = true)
    @Mapping(target = "notes", ignore = true)
    @Mapping(target = "created", ignore = true)
    @Mapping(target = "modified", ignore = true)
    Story toEntity(StoryRequestTo requestTo);

    @Mapping(target = "creatorId", source = "creator.id")
    StoryResponseTo toResponseTo(Story story);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "creator", ignore = true)
    @Mapping(target = "marks", ignore = true)
    @Mapping(target = "notes", ignore = true)
    @Mapping(target = "created", ignore = true)
    @Mapping(target = "modified", ignore = true)
    void updateEntity(@MappingTarget Story target, StoryRequestTo source);
}