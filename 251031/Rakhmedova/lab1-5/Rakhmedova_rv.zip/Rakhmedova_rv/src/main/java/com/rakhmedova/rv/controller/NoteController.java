package com.rakhmedova.rv.controller;

import com.rakhmedova.rv.dto.NoteRequestTo;
import com.rakhmedova.rv.dto.NoteResponseTo;
import com.rakhmedova.rv.service.NoteService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigInteger;
import java.util.List;

@RestController
@RequestMapping("/api/v1/notes")
@Tag(name = "Notes", description = "Operations with notes")
public class NoteController {
    private final NoteService service;

    public NoteController(NoteService service) {
        this.service = service;
    }

    @PostMapping("/stories/{storyId}")
    @Operation(summary = "Create a new note for a story")
    @ApiResponse(responseCode = "201", description = "Note created successfully")
    @ApiResponse(responseCode = "404", description = "Story not found")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    public ResponseEntity<NoteResponseTo> create(
            @Parameter(description = "Story ID", required = true) @PathVariable BigInteger storyId,
            @Parameter(description = "Note data", required = true) @Valid @RequestBody NoteRequestTo request) {
        NoteResponseTo response = service.create(request, storyId);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get note by ID")
    @ApiResponse(responseCode = "200", description = "Note found")
    @ApiResponse(responseCode = "404", description = "Note not found")
    public ResponseEntity<NoteResponseTo> findById(
            @Parameter(description = "Note ID", required = true) @PathVariable BigInteger id) {
        NoteResponseTo response = service.findById(id);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping
    @Operation(summary = "Get all notes")
    @ApiResponse(responseCode = "200", description = "List of notes")
    public ResponseEntity<List<NoteResponseTo>> findAll() {
        List<NoteResponseTo> responses = service.findAll();
        return new ResponseEntity<>(responses, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update note by ID")
    @ApiResponse(responseCode = "200", description = "Note updated successfully")
    @ApiResponse(responseCode = "404", description = "Note not found")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    public ResponseEntity<NoteResponseTo> update(
            @Parameter(description = "Note ID", required = true) @PathVariable BigInteger id,
            @Parameter(description = "Updated note data", required = true) @Valid @RequestBody NoteRequestTo request) {
        NoteResponseTo response = service.update(id, request);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete note by ID")
    @ApiResponse(responseCode = "204", description = "Note deleted successfully")
    @ApiResponse(responseCode = "404", description = "Note not found")
    public ResponseEntity<Void> delete(
            @Parameter(description = "Note ID", required = true) @PathVariable BigInteger id) {
        service.delete(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}