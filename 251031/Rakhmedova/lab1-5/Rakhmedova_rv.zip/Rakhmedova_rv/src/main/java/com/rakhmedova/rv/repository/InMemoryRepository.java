package com.rakhmedova.rv.repository;

import com.rakhmedova.rv.entity.BaseEntity;
import org.springframework.stereotype.Component;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Component
public class InMemoryRepository<T extends BaseEntity> implements Repository<T> {
    private final Map<BigInteger, T> storage = new HashMap<>();
    private BigInteger idCounter = BigInteger.ZERO;

    @Override
    public T save(T entity) {
        if (entity.getId() == null) {
            entity.setId(generateId());
        }
        storage.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public Optional<T> findById(BigInteger id) {
        return Optional.ofNullable(storage.get(id));
    }

    @Override
    public List<T> findAll() {
        return new ArrayList<>(storage.values());
    }

    @Override
    public T update(T entity) {
        if (!storage.containsKey(entity.getId())) {
            throw new IllegalArgumentException("Entity with id " + entity.getId() + " not found");
        }
        storage.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public void delete(BigInteger id) {
        storage.remove(id);
    }

    private BigInteger generateId() {
        idCounter = idCounter.add(BigInteger.ONE);
        return idCounter;
    }
}