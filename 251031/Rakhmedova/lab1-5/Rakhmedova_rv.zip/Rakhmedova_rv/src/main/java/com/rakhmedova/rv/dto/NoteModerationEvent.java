package com.rakhmedova.rv.dto;

import com.rakhmedova.rv.entity.NoteStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NoteModerationEvent {
    private BigInteger noteId;
    private String content;
    private NoteStatus status;
    private LocalDateTime createdAt;
    private String moderationReason;
} 